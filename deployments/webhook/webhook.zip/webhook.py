import boto3
import botocore
import json
# from discordwebhook import Discord
from datetime import datetime, timedelta
import time
from boto3.dynamodb.conditions import Key,Attr
# from dotenv import load_dotenv

# load_dotenv()

DISCORD_WEBHOOK = "https://discord.com/api/webhooks/1232938004134236191/s-rVBxM7gVis_4K8KWP7sfcE3vNSDlwtOxrGujjEA_bxTVjnUuLu1Hs0j24Y4GJvQHCF"

BUCKET_NAME = 'automatizacion-uni-2024' # replace with your bucket name
def return_server_configuration(self):
        dynamodb = self.dynamodb

        table = dynamodb.Table(self.table_name)

        response = table.query(
            KeyConditionExpression=Key('server_name').eq(self.nombre_server),
            FilterExpression=Attr('Active').eq(True)

        )

        print(response['Items'])

def get_file_name():
    table_name = "Automatizacion-discord-dataset"
    dynamodb = boto3.resource("dynamodb")
    orders_table = dynamodb.Table(table_name)

    # sorts items in descending order based on sort key when ScanIndexForward=False
    # sorts items in ascending order based on sort key when ScanIndexForward=True which is default
    response = orders_table.query(
        KeyConditionExpression="dataset_id = :id",
        ExpressionAttributeValues={
            ":id": "1",
        },
        ScanIndexForward=False,
        Limit=1
    )

    # print(response["Items"][0]["file_name"])
    file_name = response["Items"][0]["file_name"]
    return file_name

def get_dataset_json(KEY):

    s3 = boto3.client('s3')
    try:
        # Retrieve the JSON file from S3
        response = s3.get_object(Bucket=BUCKET_NAME, Key=KEY)
        json_content = json.loads(response['Body'].read())
        return json_content
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            print("The object does not exist.")
        else:
            raise

def lambda_handler(event, context):
    print("event", event)

    dynamodb = ""
    def log_dynamodb_record(record):
        print(record['eventID'])
        print(record['eventName'])
        print(f"DynamoDB Record: {json.dumps(record['dynamodb'])}")

    for record in event['Records']:
        log_dynamodb_record(record)
        dynamodb = record['dynamodb']

    dynamodbNew= dynamodb['NewImage']
    dynamodbOld= dynamodb['OldImage']

    server_name = dynamodbNew['server_name']['S']
    Active = dynamodbNew["Active"]['BOOL']
    created_at = dynamodbNew["created_at"]['S']
    source = dynamodbNew["source"]['S']
    sport = dynamodbNew["sport"]['S']
    frequency = dynamodbNew["frequency"]['N']
    print(server_name,Active,created_at,source,sport,frequency)

    filename = get_file_name()
    print('filename', filename)
    datos = get_dataset_json(filename)
    # bot_config = return_server_configuration()
    # for titulo, descripcion, fuente, deporte, link in zip(datos["title"].values(), datos["description"].values(), datos["news source"].values(), datos["sport"].values(), datos["link"].values()):
    #             if deporte.lower() == bot_config['deporte']:
    #                  if fuente.lower() == bot_config['fuente']:
    #                     mensaje = (
    #                         "\n ESTAS SON TUS NOTICIAS DE HOY \n"
    #                         f"Título: {titulo}\n"
    #                         f"Descripción: {descripcion}\n"
    #                         f"Fuente de noticias: {fuente}\n"
    #                         f"Deporte: {deporte}\n"
    #                         f"{link}\n"
    #                         "------------------------------------"
    #                     )
    #                     # await enviar_mensaje_discord(mensaje)
    #                 elif bot_config['fuente'] == "todas":
    #                     mensaje = (
    #                         "\n ESTAS SON TUS NOTICIAS DE HOY \n"
    #                         f"Título: {titulo}\n"
    #                         f"Descripción: {descripcion}\n"
    #                         f"Fuente de noticias: {fuente}\n"
    #                         f"Deporte: {deporte}\n"
    #                         f"{link}\n"
    #                         "------------------------------------"
    #                     )
    #                     # await enviar_mensaje_discord(mensaje)
    #             elif bot_config['deporte'] == "general":
    #                 mensaje = (
    #                     "\n ESTAS SON TUS NOTICIAS DE HOY \n"
    #                     f"Título: {titulo}\n"
    #                     f"Descripción: {descripcion}\n"
    #                     f"Fuente de noticias: {fuente}\n"
    #                     f"Deporte: {deporte}\n"
    #                     f"{link}\n"
    #                     "------------------------------------"
    #                 )
    #                 # await enviar_mensaje_discord(mensaje)
    #                 if fuente.lower() == bot_config['fuente']:
    #                     mensaje = (
    #                         "\n ESTAS SON TUS NOTICIAS DE HOY \n"
    #                         f"Título: {titulo}\n"
    #                         f"Descripción: {descripcion}\n"
    #                         f"Fuente de noticias: {fuente}\n"
    #                         f"Deporte: {deporte}\n"
    #                         f"{link}\n"
    #                         "------------------------------------"
    #                     )
    #                     # await enviar_mensaje_discord(mensaje)
    #                 elif bot_config['fuente'] == "todas":
    #                     mensaje = (
    #                         "\n ESTAS SON TUS NOTICIAS DE HOY \n"
    #                         f"Título: {titulo}\n"
    #                         f"Descripción: {descripcion}\n"
    #                         f"Fuente de noticias: {fuente}\n"
    #                         f"Deporte: {deporte}\n"
    #                         f"{link}\n"
    #                         "------------------------------------"
    #                     )
    #                     # await enviar_mensaje_discord(mensaje)

    # # DISCORD_WEBHOOK = os.getenv('DISCORD_WEBHOOK')
    # discord = Discord(url=DISCORD_WEBHOOK)
    # discord.post(content="Hello, world")

